package arbeiter;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("570ac78f-9218-40d6-b37a-88b2057bfe0e")
public interface MalerarbeiterSchnittstelle {
    @objid ("d5493dbe-806c-492a-83a1-52df744f0eb8")
    void Faerbe();

}
