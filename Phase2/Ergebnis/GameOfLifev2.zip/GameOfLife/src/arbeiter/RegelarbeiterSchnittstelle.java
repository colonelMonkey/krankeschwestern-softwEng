package arbeiter;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b9cdd87b-dddc-4783-ab16-8968d664b6ce")
public interface RegelarbeiterSchnittstelle {
    @objid ("2d9dfa39-267e-4118-93b6-8b925271e66f")
    void transit();

}
