package java.awt.color;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28a0-0000-000000000000")
public class CMMException extends RuntimeException {
}
