package java.awt.color;

import java.io.Serializable;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28a1-0000-000000000000")
public class ICC_Profile implements Serializable {
}
