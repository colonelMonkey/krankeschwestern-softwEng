package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2951-0000-000000000000")
public class TextArea extends TextComponent {
    @objid ("0a2c8719-d120-49a8-9564-57ec6f588bcc")
    protected class AccessibleAWTTextArea extends AccessibleAWTTextComponent {
    }

}
