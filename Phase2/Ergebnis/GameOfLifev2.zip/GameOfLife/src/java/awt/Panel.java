package java.awt;

import javax.accessibility.Accessible;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-29b6-0000-000000000000")
public class Panel extends Container implements Accessible {
    @objid ("3c59cf78-f8aa-4826-8753-0f501526514c")
    protected class AccessibleAWTPanel extends AccessibleAWTContainer {
    }

}
