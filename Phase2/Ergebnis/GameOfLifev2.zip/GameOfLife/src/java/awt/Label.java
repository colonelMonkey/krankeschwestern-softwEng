package java.awt;

import javax.accessibility.Accessible;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-29a8-0000-000000000000")
public class Label extends Component implements Accessible {
    @objid ("5320c9d3-d588-428a-8ddd-ff4f00fa39f0")
    protected class AccessibleAWTLabel extends AccessibleAWTComponent {
    }

}
