package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("01ec0d38-0000-1ae5-0000-000000000000")
public class Desktop {
    @objid ("bebe491a-7acc-4d0b-bd33-939d4743e6c1")
    public enum Action {
        ;
    }

}
