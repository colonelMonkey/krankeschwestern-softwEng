package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2899-0000-000000000000")
public abstract class GraphicsDevice {
    @objid ("8a1e4118-cbbf-4756-bfc7-cd229d3f8e7f")
    public enum WindowTranslucency {
        ;
    }

}
