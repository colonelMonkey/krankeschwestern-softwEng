package java.awt.event;

import java.util.EventListener;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2868-0000-000000000000")
public interface ActionListener extends EventListener {
    @objid ("8cc86026-9046-4502-8396-60e07eb99a29")
    void actionPerformed(ActionEvent p0);

}
