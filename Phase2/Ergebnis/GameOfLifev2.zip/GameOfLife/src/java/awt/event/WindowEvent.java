package java.awt.event;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-286c-0000-000000000000")
public class WindowEvent extends ComponentEvent {
}
