package java.awt.event;

import java.util.EventListener;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2870-0000-000000000000")
public interface TextListener extends EventListener {
    @objid ("ba32911b-e175-47e3-be92-b55b17a631a3")
    void textValueChanged(TextEvent p0);

}
