package java.awt.event;

import java.awt.AWTEvent;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-285b-0000-000000000000")
public class TextEvent extends AWTEvent {
}
