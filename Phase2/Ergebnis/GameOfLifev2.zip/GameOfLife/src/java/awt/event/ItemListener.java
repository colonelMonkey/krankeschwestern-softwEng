package java.awt.event;

import java.util.EventListener;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-285d-0000-000000000000")
public interface ItemListener extends EventListener {
    @objid ("a90cc228-df48-4b33-a7d3-fe83a0bc8c2e")
    void itemStateChanged(ItemEvent p0);

}
