package java.awt.event;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2867-0000-000000000000")
public class KeyEvent extends InputEvent {
}
