package java.awt.event;

import java.awt.AWTEvent;
import java.awt.ActiveEvent;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-286a-0000-000000000000")
public class InvocationEvent extends AWTEvent implements ActiveEvent {
}
