package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-287b-0000-000000000000")
public interface Stroke {
    @objid ("871afce7-c977-4da1-9292-1c6db17d0283")
    Shape createStrokedShape(Shape p0);

}
