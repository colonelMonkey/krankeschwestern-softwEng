package java.awt;

import javax.accessibility.Accessible;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2909-0000-000000000000")
public class ScrollPane extends Container implements Accessible {
    @objid ("e81b8e1a-5247-4dd3-a477-7d240a1b7dca")
    protected class AccessibleAWTScrollPane extends AccessibleAWTContainer {
    }

}
