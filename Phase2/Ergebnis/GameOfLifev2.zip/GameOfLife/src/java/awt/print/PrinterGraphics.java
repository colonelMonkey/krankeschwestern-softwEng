package java.awt.print;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28fd-0000-000000000000")
public interface PrinterGraphics {
    @objid ("95c49aef-04bf-4adc-b025-0c9db9729856")
    PrinterJob getPrinterJob();

}
