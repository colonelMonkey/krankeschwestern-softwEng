package java.awt.print;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2900-0000-000000000000")
public class PrinterAbortException extends PrinterException {
}
