package java.awt;

import javax.accessibility.Accessible;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2955-0000-000000000000")
public class Canvas extends Component implements Accessible {
    @objid ("ebd3a31d-e4af-4c9f-822a-f987e972ab96")
    protected class AccessibleAWTCanvas extends AccessibleAWTComponent {
    }

}
