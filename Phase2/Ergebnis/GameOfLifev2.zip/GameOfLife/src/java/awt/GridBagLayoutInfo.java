package java.awt;

import java.io.Serializable;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("01ec0d38-0000-1ae0-0000-000000000000")
public class GridBagLayoutInfo implements Serializable {
}
