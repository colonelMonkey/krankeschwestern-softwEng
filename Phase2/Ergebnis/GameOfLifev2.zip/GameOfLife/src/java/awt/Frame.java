package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2968-0000-000000000000")
public class Frame extends Window implements MenuContainer {
    @objid ("f7614f49-a335-4dfc-9ba9-9d5313c3baa7")
    protected class AccessibleAWTFrame extends AccessibleAWTWindow {
    }

}
