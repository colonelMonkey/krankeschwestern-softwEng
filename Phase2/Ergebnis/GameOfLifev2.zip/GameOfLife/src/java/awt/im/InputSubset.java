package java.awt.im;

import java.lang.Character.Subset;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2933-0000-000000000000")
public final class InputSubset extends Subset {
}
