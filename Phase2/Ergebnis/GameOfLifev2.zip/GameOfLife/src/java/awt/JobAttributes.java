package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28f4-0000-000000000000")
public final class JobAttributes implements Cloneable {
    @objid ("00d00398-0000-28f5-0000-000000000000")
    public static final class DefaultSelectionType {
    }

    @objid ("00d00398-0000-28f6-0000-000000000000")
    public static final class DestinationType {
    }

    @objid ("00d00398-0000-28f7-0000-000000000000")
    public static final class DialogType {
    }

    @objid ("00d00398-0000-28f8-0000-000000000000")
    public static final class MultipleDocumentHandlingType {
    }

    @objid ("00d00398-0000-28f9-0000-000000000000")
    public static final class SidesType {
    }

}
