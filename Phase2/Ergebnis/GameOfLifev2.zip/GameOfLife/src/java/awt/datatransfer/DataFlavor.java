package java.awt.datatransfer;

import java.io.Externalizable;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2926-0000-000000000000")
public class DataFlavor implements Externalizable, Cloneable {
}
