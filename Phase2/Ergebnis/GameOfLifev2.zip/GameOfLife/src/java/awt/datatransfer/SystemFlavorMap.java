package java.awt.datatransfer;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2929-0000-000000000000")
public final class SystemFlavorMap implements FlavorMap, FlavorTable {
}
