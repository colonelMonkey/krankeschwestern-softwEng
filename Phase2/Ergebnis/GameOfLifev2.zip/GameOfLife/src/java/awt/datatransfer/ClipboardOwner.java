package java.awt.datatransfer;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2923-0000-000000000000")
public interface ClipboardOwner {
    @objid ("23491a52-958c-4f1c-a07d-35bcd4b5fbac")
    void lostOwnership(Clipboard p0, Transferable p1);

}
