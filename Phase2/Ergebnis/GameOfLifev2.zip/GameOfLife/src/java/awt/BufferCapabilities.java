package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28a3-0000-000000000000")
public class BufferCapabilities implements Cloneable {
    @objid ("00d00398-0000-28a4-0000-000000000000")
    public static final class FlipContents {
    }

}
