package java.awt.peer;

import java.awt.Event;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28d9-0000-000000000000")
public interface PopupMenuPeer extends MenuPeer {
    @objid ("e2806f79-a8dd-4bcc-a0bd-cb06f06c863a")
    void show(Event p0);

}
