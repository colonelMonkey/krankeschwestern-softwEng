package java.awt.peer;

import java.awt.Font;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28e8-0000-000000000000")
public interface MenuComponentPeer {
    @objid ("3f4628d7-43cc-480d-b11d-e566382e588c")
    void dispose();

    @objid ("a1155335-e743-4690-aeff-5e61683f2c1a")
    void setFont(Font p0);

}
