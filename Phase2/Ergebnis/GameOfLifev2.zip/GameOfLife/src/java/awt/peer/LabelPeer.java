package java.awt.peer;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28d7-0000-000000000000")
public interface LabelPeer extends ComponentPeer {
    @objid ("6ea7239a-6883-48cb-9b3a-e7301218ab7b")
    void setAlignment(int p0);

    @objid ("1b5e65b6-a0e9-441b-98a9-4f4915c8e58a")
    void setText(String p0);

}
