package java.awt.peer;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28e7-0000-000000000000")
public interface MenuItemPeer extends MenuComponentPeer {
    @objid ("a7d406fd-50a5-4d1a-a818-3ba5ac9b2047")
    void setEnabled(boolean p0);

    @objid ("d7e72097-cf7e-414b-9907-710f186c98f5")
    void setLabel(String p0);

}
