package java.awt.peer;

import java.awt.Dimension;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("01ec0d38-0000-1a81-0000-000000000000")
public interface SystemTrayPeer {
    @objid ("749f280e-ae42-41b5-8f40-6802404e237b")
    Dimension getTrayIconSize();

}
