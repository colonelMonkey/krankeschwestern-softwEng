package java.awt.peer;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28df-0000-000000000000")
public interface LightweightPeer extends ComponentPeer {
}
