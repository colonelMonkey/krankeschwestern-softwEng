package java.awt.peer;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28da-0000-000000000000")
public interface ButtonPeer extends ComponentPeer {
    @objid ("565c5d2b-359a-47e5-8439-c27562b03baf")
    void setLabel(String p0);

}
