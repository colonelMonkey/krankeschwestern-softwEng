package java.awt.peer;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28f3-0000-000000000000")
public interface CheckboxMenuItemPeer extends MenuItemPeer {
    @objid ("0c6ca68e-9b8b-4c33-89b1-ddbfb47e6f4d")
    void setState(boolean p0);

}
