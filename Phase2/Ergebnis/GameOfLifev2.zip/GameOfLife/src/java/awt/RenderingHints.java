package java.awt;

import java.util.Map;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-29a4-0000-000000000000")
public class RenderingHints implements Map, Cloneable {
    @objid ("00d00398-0000-29a5-0000-000000000000")
    public static abstract class Key {
    }

}
