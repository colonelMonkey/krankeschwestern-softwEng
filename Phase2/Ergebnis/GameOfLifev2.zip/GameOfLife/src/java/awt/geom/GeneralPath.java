package java.awt.geom;

import java.awt.geom.Path2D.Float;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28b6-0000-000000000000")
public final class GeneralPath extends Float {
}
