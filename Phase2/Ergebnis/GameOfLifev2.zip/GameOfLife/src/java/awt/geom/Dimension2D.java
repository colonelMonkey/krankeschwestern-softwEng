package java.awt.geom;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28b8-0000-000000000000")
public abstract class Dimension2D implements Cloneable {
}
