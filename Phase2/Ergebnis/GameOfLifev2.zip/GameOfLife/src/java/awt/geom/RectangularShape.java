package java.awt.geom;

import java.awt.Shape;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28b9-0000-000000000000")
public abstract class RectangularShape implements Shape, Cloneable {
}
