package java.awt.geom;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28ca-0000-000000000000")
public class IllegalPathStateException extends RuntimeException {
}
