package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("01ec0d38-0000-1ae2-0000-000000000000")
public class TrayIcon {
    @objid ("93eb73b9-2ee8-4a63-bed1-d933bd9ce51d")
    public enum MessageType {
        ;
    }

}
