package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2950-0000-000000000000")
public abstract class Image {
}
