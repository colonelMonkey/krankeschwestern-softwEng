package java.awt.image;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-282f-0000-000000000000")
public interface TileObserver {
    @objid ("12432367-a93f-4382-a059-e0efafcd570d")
    void tileUpdate(WritableRenderedImage p0, int p1, int p2, boolean p3);

}
