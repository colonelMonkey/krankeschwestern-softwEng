package java.awt.image;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-281a-0000-000000000000")
public class BandCombineOp implements RasterOp {
}
