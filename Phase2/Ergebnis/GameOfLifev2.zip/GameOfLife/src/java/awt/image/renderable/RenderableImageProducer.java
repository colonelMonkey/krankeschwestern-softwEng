package java.awt.image.renderable;

import java.awt.image.ImageProducer;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2817-0000-000000000000")
public class RenderableImageProducer implements ImageProducer, Runnable {
}
