package java.awt.image.renderable;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2818-0000-000000000000")
public class RenderableImageOp implements RenderableImage {
}
