package java.awt.image;

import java.awt.Image;
import java.awt.Transparency;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-281f-0000-000000000000")
public abstract class VolatileImage extends Image implements Transparency {
}
