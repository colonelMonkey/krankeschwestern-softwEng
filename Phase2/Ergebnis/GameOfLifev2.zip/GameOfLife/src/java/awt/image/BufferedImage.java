package java.awt.image;

import java.awt.Image;
import java.awt.Transparency;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-280a-0000-000000000000")
public class BufferedImage extends Image implements WritableRenderedImage, Transparency {
}
