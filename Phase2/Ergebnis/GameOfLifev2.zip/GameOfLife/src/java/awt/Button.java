package java.awt;

import javax.accessibility.Accessible;
import javax.accessibility.AccessibleAction;
import javax.accessibility.AccessibleValue;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2845-0000-000000000000")
public class Button extends Component implements Accessible {
    @objid ("26342f94-244a-40f8-8a9f-20b1e821e054")
    protected class AccessibleAWTButton extends AccessibleAWTComponent implements AccessibleAction, AccessibleValue {
    }

}
