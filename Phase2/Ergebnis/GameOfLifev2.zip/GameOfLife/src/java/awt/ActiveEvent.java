package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2949-0000-000000000000")
public interface ActiveEvent {
    @objid ("0f515ac7-6cf2-4c33-98b6-bd2cb0d233f4")
    void dispatch();

}
