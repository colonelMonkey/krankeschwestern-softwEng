package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-294c-0000-000000000000")
public interface PrintGraphics {
    @objid ("31a743c3-0897-4725-9adc-8bb4a44a2830")
    PrintJob getPrintJob();

}
