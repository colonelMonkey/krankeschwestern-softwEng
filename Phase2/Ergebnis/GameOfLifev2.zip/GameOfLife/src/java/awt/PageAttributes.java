package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2875-0000-000000000000")
public final class PageAttributes implements Cloneable {
    @objid ("00d00398-0000-2876-0000-000000000000")
    public static final class ColorType {
    }

    @objid ("00d00398-0000-2877-0000-000000000000")
    public static final class MediaType {
    }

    @objid ("00d00398-0000-2878-0000-000000000000")
    public static final class OrientationRequestedType {
    }

    @objid ("00d00398-0000-2879-0000-000000000000")
    public static final class OriginType {
    }

    @objid ("00d00398-0000-287a-0000-000000000000")
    public static final class PrintQualityType {
    }

}
