package java.awt.dnd;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2806-0000-000000000000")
public abstract class DragSourceAdapter implements DragSourceListener, DragSourceMotionListener {
}
