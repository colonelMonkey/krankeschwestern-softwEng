package java.awt.dnd;

import java.awt.datatransfer.Transferable;
import java.io.Serializable;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-27ed-0000-000000000000")
public class DropTargetContext implements Serializable {
    @objid ("8e201f51-f8ce-49f6-b6f6-0f2be72bdf1d")
    protected class TransferableProxy implements Transferable {
    }

}
