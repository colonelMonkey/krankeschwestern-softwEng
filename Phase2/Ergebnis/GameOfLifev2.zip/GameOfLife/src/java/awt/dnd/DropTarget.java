package java.awt.dnd;

import java.awt.event.ActionListener;
import java.io.Serializable;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-27eb-0000-000000000000")
public class DropTarget implements DropTargetListener, Serializable {
    @objid ("c726cd7d-b7fe-4531-a830-b32565bdb9fb")
    protected static class DropTargetAutoScroller implements ActionListener {
    }

}
