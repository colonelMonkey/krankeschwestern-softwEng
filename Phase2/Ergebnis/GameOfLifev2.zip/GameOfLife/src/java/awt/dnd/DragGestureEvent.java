package java.awt.dnd;

import java.util.EventObject;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-27fa-0000-000000000000")
public class DragGestureEvent extends EventObject {
}
