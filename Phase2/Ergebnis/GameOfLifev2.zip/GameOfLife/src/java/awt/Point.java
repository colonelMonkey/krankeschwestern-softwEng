package java.awt;

import java.awt.geom.Point2D;
import java.io.Serializable;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2982-0000-000000000000")
public class Point extends Point2D implements Serializable {
}
