package java.awt;

import java.awt.event.KeyEvent;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-29b8-0000-000000000000")
public interface KeyEventDispatcher {
    @objid ("d3a1389e-947d-4ef6-bbee-dbedb62fc11f")
    boolean dispatchKeyEvent(KeyEvent p0);

}
