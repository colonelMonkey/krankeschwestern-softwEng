package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-291b-0000-000000000000")
public class PopupMenu extends Menu {
    @objid ("c53bd07d-d7bd-4637-8240-aebd8b4a7088")
    protected class AccessibleAWTPopupMenu extends AccessibleAWTMenu {
    }

}
