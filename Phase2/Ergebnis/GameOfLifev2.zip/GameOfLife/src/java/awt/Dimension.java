package java.awt;

import java.awt.geom.Dimension2D;
import java.io.Serializable;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-297a-0000-000000000000")
public class Dimension extends Dimension2D implements Serializable {
}
