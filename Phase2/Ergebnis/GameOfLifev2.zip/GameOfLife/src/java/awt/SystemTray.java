package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("01ec0d38-0000-1adc-0000-000000000000")
public class SystemTray {
}
