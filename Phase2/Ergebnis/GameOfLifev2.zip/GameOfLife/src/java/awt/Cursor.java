package java.awt;

import java.io.Serializable;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-294d-0000-000000000000")
public class Cursor implements Serializable {
}
