package java.awt.font;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2895-0000-000000000000")
public final class TextMeasurer implements Cloneable {
}
