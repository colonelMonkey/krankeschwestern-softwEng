package java.awt.font;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2888-0000-000000000000")
public final class TextLayout implements Cloneable {
    @objid ("00d00398-0000-2889-0000-000000000000")
    public static class CaretPolicy {
    }

}
