package java.awt.font;

import java.text.AttributedCharacterIterator.Attribute;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-288c-0000-000000000000")
public final class TextAttribute extends Attribute {
}
