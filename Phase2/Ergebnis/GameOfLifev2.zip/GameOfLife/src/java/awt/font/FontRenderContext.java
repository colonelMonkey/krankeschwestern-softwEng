package java.awt.font;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2882-0000-000000000000")
public class FontRenderContext {
}
