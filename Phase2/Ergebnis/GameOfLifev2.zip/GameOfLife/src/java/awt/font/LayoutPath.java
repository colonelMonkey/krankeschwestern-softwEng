package java.awt.font;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("01ec0d38-0000-1a57-0000-000000000000")
public abstract class LayoutPath {
}
