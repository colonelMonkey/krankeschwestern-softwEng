package java.awt.font;

import java.io.Serializable;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2896-0000-000000000000")
public final class NumericShaper implements Serializable {
    @objid ("2e0b1cfc-6e87-4f37-a64e-ca7ae406c0a3")
    public enum Range {
        ;
    }

}
