package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-28d4-0000-000000000000")
public class TextField extends TextComponent {
    @objid ("3c1c4df5-da52-433b-85ca-8850e4299aa6")
    protected class AccessibleAWTTextField extends AccessibleAWTTextComponent {
    }

}
