package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("01ec0d38-0000-1ab8-0000-000000000000")
public abstract class MultipleGradientPaint implements Paint {
    @objid ("a30c5c8e-2211-4eef-b39e-a3bd6a745ea8")
    public enum ColorSpaceType {
        ;
    }

    @objid ("bf3cb0b4-309b-449f-b5d8-c47b12809be9")
    public enum CycleMethod {
        ;
    }

}
