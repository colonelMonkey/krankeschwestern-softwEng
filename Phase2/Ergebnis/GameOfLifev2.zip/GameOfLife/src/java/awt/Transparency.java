package java.awt;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2984-0000-000000000000")
public interface Transparency {
    @objid ("91f0b602-8f64-4e24-bf1a-340ff3b07242")
    int getTransparency();

}
