package java.io;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2e11-0000-000000000000")
public abstract class FilterWriter extends Writer {
}
