package java.io;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2e4a-0000-000000000000")
public abstract class ObjectStreamException extends IOException {
}
