package java.io;

import java.security.BasicPermission;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2e33-0000-000000000000")
public final class SerializablePermission extends BasicPermission {
}
