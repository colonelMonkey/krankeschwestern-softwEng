package java.io;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2dff-0000-000000000000")
public class PipedWriter extends Writer {
}
