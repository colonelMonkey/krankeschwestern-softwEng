package java.io;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("01ec0d38-0000-1d8b-0000-000000000000")
public class IOError extends Error {
}
