package java.io;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2e24-0000-000000000000")
public interface FileFilter {
    @objid ("b0b65b49-630a-4cee-9eef-28fa3cd58793")
    boolean accept(File p0);

}
