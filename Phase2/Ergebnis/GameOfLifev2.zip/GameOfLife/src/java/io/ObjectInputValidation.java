package java.io;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2e00-0000-000000000000")
public interface ObjectInputValidation {
    @objid ("7ad26c47-1675-4626-9fb8-da7fe9c8628d")
    void validateObject() throws InvalidObjectException;

}
