package java.io;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("01ec0d38-0000-1d69-0000-000000000000")
public final class Console implements Flushable {
}
