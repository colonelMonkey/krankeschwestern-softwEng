package java.io;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2e01-0000-000000000000")
public interface Flushable {
    @objid ("b00c64fc-7672-4ad6-8f4e-665935edc8ac")
    void flush() throws IOException;

}
