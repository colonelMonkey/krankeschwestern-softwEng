package java.applet;

import java.awt.Panel;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2ed7-0000-000000000000")
public class Applet extends Panel {
    @objid ("0cb66c47-01b5-4fe4-8f46-2ff35cbe916a")
    protected class AccessibleApplet extends AccessibleAWTPanel {
    }

}
