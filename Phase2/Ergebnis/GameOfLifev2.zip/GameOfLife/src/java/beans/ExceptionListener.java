package java.beans;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2a9c-0000-000000000000")
public interface ExceptionListener {
    @objid ("a1fea3bf-41e2-4d19-acdf-7a0d8a8a768a")
    void exceptionThrown(Exception p0);

}
