package java.beans.beancontext;

import java.awt.Container;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2a5a-0000-000000000000")
public interface BeanContextContainerProxy {
    @objid ("e3ec9c93-1009-4ef0-9421-863d51b52c81")
    Container getContainer();

}
