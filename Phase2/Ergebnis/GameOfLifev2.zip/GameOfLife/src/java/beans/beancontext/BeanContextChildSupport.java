package java.beans.beancontext;

import java.io.Serializable;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2a57-0000-000000000000")
public class BeanContextChildSupport implements BeanContextChild, BeanContextServicesListener, Serializable {
}
