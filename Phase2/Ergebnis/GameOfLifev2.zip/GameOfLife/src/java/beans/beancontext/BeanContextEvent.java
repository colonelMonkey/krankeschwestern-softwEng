package java.beans.beancontext;

import java.util.EventObject;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2a59-0000-000000000000")
public abstract class BeanContextEvent extends EventObject {
}
