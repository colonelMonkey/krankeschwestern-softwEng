package java.beans.beancontext;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2a65-0000-000000000000")
public interface BeanContextProxy {
    @objid ("e7ad420c-8f08-470a-a3a0-d5c705d3df89")
    BeanContextChild getBeanContextProxy();

}
