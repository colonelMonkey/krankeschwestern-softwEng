package java.beans.beancontext;

import java.awt.Component;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2a60-0000-000000000000")
public interface BeanContextChildComponentProxy {
    @objid ("99c782b4-8397-4db0-9c79-eb2cb473cd01")
    Component getComponent();

}
