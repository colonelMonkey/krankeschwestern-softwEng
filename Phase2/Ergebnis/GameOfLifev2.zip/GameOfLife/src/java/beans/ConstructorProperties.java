package java.beans;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("dd7097db-1869-4efa-b8f5-6bbe04789053")
public abstract @interface ConstructorProperties  {
}
