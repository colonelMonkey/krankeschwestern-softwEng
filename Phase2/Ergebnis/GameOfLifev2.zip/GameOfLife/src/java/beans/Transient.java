package java.beans;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("52fd5b4f-63e9-4afe-bcf8-c2849a51b8e6")
public abstract @interface Transient  {
}
