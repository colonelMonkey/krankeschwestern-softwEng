package java.beans;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("00d00398-0000-2ab8-0000-000000000000")
public class MethodDescriptor extends FeatureDescriptor {
}
